package g

const (
	VERSION = "0.1.0"
)

//0.0.2 fix event_id error
//0.1.0 support send sms shell
