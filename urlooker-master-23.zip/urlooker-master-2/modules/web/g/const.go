package g

const (
	VERSION = "0.2.0"
)

//0.0.2 fix event_id报错，加强user信息保护，增加管理员编辑功能
//0.0.3 fix err处理异常
//0.0.4 fix 登陆问题
//0.1.0 增加ldap登陆;域名可以指定ip
//0.2.0 增加策略禁用功能
//1.1.0 增加自定义endpoint，禁止注册，post请求探测，dns解析优化，header自定义
